package autofirma

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"math"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"time"
)

type Rect struct {
	Page int
	LLX  float64
	LLY  float64
	URX  float64
	URY  float64
}

type SignOptions struct {
	AutoFirmaPath        string
	InputPath            string
	OutputPath           string
	Rect                 Rect
	Layer2Text           string
	FontSize             int
	FontFamily           int
	FontStyle            int
	FontColor            string
	Headless             bool
	CertGUI              bool
	GUI                  bool
	Store                string
	Password             string
	Alias                string
	Filter               string
	Algorithm            string
	Format               string
	ExtraParams          map[string]string
	Timeout              time.Duration
	DryRun               bool
	Verbose              bool
	PreserveConfigSpaces bool
	ConfigSeparator      string
	Visible              bool
}

type AliasOptions struct {
	AutoFirmaPath string
	Store         string
	Password      string
	XML           bool
	Timeout       time.Duration
}

type Result struct {
	Command string
	Args    []string
	Config  string
	Stdout  string
	Stderr  string
}

func DetectExecutable(explicit string) (string, error) {
	if explicit != "" {
		if isExecutablePath(explicit) {
			return explicit, nil
		}
		if p, err := exec.LookPath(explicit); err == nil {
			return p, nil
		}
		return "", fmt.Errorf("no se encontró AutoFirma en %q", explicit)
	}

	seen := map[string]bool{}
	for _, c := range executableCandidates() {
		if c == "" || seen[c] {
			continue
		}
		seen[c] = true
		if strings.ContainsRune(c, os.PathSeparator) || filepath.IsAbs(c) {
			if isExecutablePath(c) {
				return c, nil
			}
			continue
		}
		if p, err := exec.LookPath(c); err == nil {
			return p, nil
		}
	}
	return "", errors.New("no se encontró AutoFirma; instala AutoFirma, añádelo al PATH o usa --autofirma /ruta/al/binario")
}

func executableCandidates() []string {
	candidates := []string{"AutoFirma", "autofirma", "Autofirma", "AutoFirmaCommandLine", "AutofirmaCommandLine", "autofirmacommandline"}
	switch runtime.GOOS {
	case "linux":
		candidates = append([]string{
			"/usr/bin/AutoFirma",
			"/usr/bin/autofirma",
			"/usr/bin/Autofirma",
			"/usr/local/bin/AutoFirma",
			"/usr/local/bin/autofirma",
		}, candidates...)
	case "windows":
		candidates = append([]string{
			"AutoFirmaCommandLine.exe",
			"AutoFirma.exe",
			"AutofirmaCommandLine.exe",
			"autofirmacommandline.exe",
		}, candidates...)
		candidates = append(candidates, windowsAutoFirmaCandidates()...)
	}
	return candidates
}

func windowsAutoFirmaCandidates() []string {
	if runtime.GOOS != "windows" {
		return nil
	}
	var out []string
	for _, base := range []string{os.Getenv("ProgramFiles"), os.Getenv("ProgramFiles(x86)"), os.Getenv("LOCALAPPDATA")} {
		if base == "" {
			continue
		}
		for _, rel := range []string{
			filepath.Join("AutoFirma", "AutoFirmaCommandLine.exe"),
			filepath.Join("AutoFirma", "AutoFirma.exe"),
			filepath.Join("AutoFirma", "AutofirmaCommandLine.exe"),
			filepath.Join("AutoFirma", "autofirmacommandline.exe"),
		} {
			out = append(out, filepath.Join(base, rel))
		}
	}
	return out
}

func Sign(ctx context.Context, opts SignOptions) (Result, error) {
	if opts.InputPath == "" || opts.OutputPath == "" {
		return Result{}, errors.New("InputPath y OutputPath son obligatorios")
	}
	if opts.Rect.Page <= 0 {
		return Result{}, errors.New("la página de firma debe ser >= 1")
	}
	if opts.Format == "" {
		opts.Format = "PAdES"
	}
	if opts.Algorithm == "" {
		opts.Algorithm = "SHA256withRSA"
	}
	if opts.FontSize <= 0 {
		opts.FontSize = 8
	}
	if opts.FontColor == "" {
		opts.FontColor = "black"
	}
	if opts.Timeout <= 0 {
		opts.Timeout = 10 * time.Minute
	}

	config := BuildConfig(opts)
	afPath, err := DetectExecutable(opts.AutoFirmaPath)
	if err != nil {
		if !opts.DryRun {
			return Result{}, err
		}
		afPath = opts.AutoFirmaPath
		if afPath == "" {
			afPath = "AutoFirma"
			if runtime.GOOS == "windows" {
				afPath = "AutoFirmaCommandLine.exe"
			}
		}
	}

	if err := os.MkdirAll(filepath.Dir(opts.OutputPath), 0o755); err != nil {
		return Result{}, fmt.Errorf("no se pudo crear el directorio de salida: %w", err)
	}

	args := []string{"sign"}
	if opts.GUI {
		args = append(args, "-gui")
	} else if opts.CertGUI {
		args = append(args, "-certgui")
	}
	args = append(args,
		"-i", opts.InputPath,
		"-o", opts.OutputPath,
		"-algorithm", opts.Algorithm,
		"-format", opts.Format,
	)
	if strings.TrimSpace(config) != "" {
		args = append(args, "-config", config)
	}
	if opts.Store != "" {
		args = append(args, "-store", opts.Store)
	}
	if opts.Password != "" {
		args = append(args, "-password", opts.Password)
	}
	if opts.Alias != "" {
		args = append(args, "-alias", opts.Alias)
	}
	if opts.Filter != "" {
		args = append(args, "-filter", opts.Filter)
	}

	res := Result{Command: afPath, Args: append([]string(nil), args...), Config: config}
	if opts.DryRun {
		return res, nil
	}

	ctx, cancel := context.WithTimeout(ctx, opts.Timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, afPath, args...)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	err = cmd.Run()
	res.Stdout = stdout.String()
	res.Stderr = stderr.String()
	if ctx.Err() != nil {
		return res, fmt.Errorf("AutoFirma excedió el tiempo máximo (%s): %w", opts.Timeout, ctx.Err())
	}
	if err != nil {
		return res, formatAutoFirmaError(err, res)
	}
	if _, err := os.Stat(opts.OutputPath); err != nil {
		return res, fmt.Errorf("AutoFirma terminó sin error, pero no existe el fichero de salida %q: %w", opts.OutputPath, err)
	}
	return res, nil
}

func ListAliases(ctx context.Context, opts AliasOptions) (Result, error) {
	if opts.Timeout <= 0 {
		opts.Timeout = 2 * time.Minute
	}
	afPath, err := DetectExecutable(opts.AutoFirmaPath)
	if err != nil {
		return Result{}, err
	}
	args := []string{"listaliases"}
	if opts.Store != "" {
		args = append(args, "-store", opts.Store)
	}
	if opts.Password != "" {
		args = append(args, "-password", opts.Password)
	}
	if opts.XML {
		args = append(args, "-xml")
	}
	res := Result{Command: afPath, Args: append([]string(nil), args...)}
	ctx, cancel := context.WithTimeout(ctx, opts.Timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, afPath, args...)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	err = cmd.Run()
	res.Stdout = stdout.String()
	res.Stderr = stderr.String()
	if ctx.Err() != nil {
		return res, fmt.Errorf("AutoFirma excedió el tiempo máximo (%s): %w", opts.Timeout, ctx.Err())
	}
	if err != nil {
		return res, formatAutoFirmaError(err, res)
	}
	return res, nil
}

const DefaultLayer2Text = ""

func DefaultConfigSeparator() string {
	// The Linux AutoFirma wrappers that motivated this project are picky about
	// literal \n. Windows builds usually receive argv directly and often tolerate
	// real newlines. Keep literal as the conservative default; users can switch
	// with --config-separator newline after testing their AutoFirma build.
	return "literal"
}

func BuildConfig(opts SignOptions) string {
	props := map[string]string{}
	if opts.Headless {
		props["headLess"] = "true"
	}
	if opts.Visible {
		props["signaturePositionOnPageUpperRightY"] = fmtFloat(opts.Rect.URY)
		props["signaturePositionOnPageUpperRightX"] = fmtFloat(opts.Rect.URX)
		props["signaturePositionOnPageLowerLeftY"] = fmtFloat(opts.Rect.LLY)
		props["signaturePositionOnPageLowerLeftX"] = fmtFloat(opts.Rect.LLX)
		props["signaturePage"] = fmt.Sprintf("%d", opts.Rect.Page)
		if strings.TrimSpace(opts.Layer2Text) != "" {
			props["layer2Text"] = normalizeConfigValue(opts.Layer2Text, opts.PreserveConfigSpaces)
			props["layer2FontSize"] = fmt.Sprintf("%d", opts.FontSize)
			props["layer2FontFamily"] = fmt.Sprintf("%d", opts.FontFamily)
			props["layer2FontStyle"] = fmt.Sprintf("%d", opts.FontStyle)
			props["layer2FontColor"] = opts.FontColor
		}
	}
	for k, v := range opts.ExtraParams {
		if strings.TrimSpace(k) == "" {
			continue
		}
		props[strings.TrimSpace(k)] = normalizeConfigValue(v, opts.PreserveConfigSpaces)
	}

	preferred := []string{
		"headLess",
		"signaturePositionOnPageUpperRightY",
		"signaturePositionOnPageUpperRightX",
		"signaturePositionOnPageLowerLeftY",
		"signaturePositionOnPageLowerLeftX",
		"signaturePage",
		"layer2Text",
		"layer2FontSize",
		"layer2FontFamily",
		"layer2FontStyle",
		"layer2FontColor",
	}
	used := map[string]bool{}
	lines := make([]string, 0, len(props))
	for _, k := range preferred {
		if v, ok := props[k]; ok {
			lines = append(lines, k+"="+v)
			used[k] = true
		}
	}
	var rest []string
	for k := range props {
		if !used[k] {
			rest = append(rest, k)
		}
	}
	sort.Strings(rest)
	for _, k := range rest {
		lines = append(lines, k+"="+props[k])
	}

	switch strings.ToLower(strings.TrimSpace(opts.ConfigSeparator)) {
	case "", "literal", "backslash-n", "slash-n":
		return strings.Join(lines, `\n`)
	case "newline", "lf":
		return strings.Join(lines, "\n")
	default:
		return strings.Join(lines, `\n`)
	}
}

func PrettyConfig(config string) string {
	return strings.ReplaceAll(config, `\n`, "\n")
}

func ShellQuote(args []string) string {
	return shellQuote(args, nil)
}

func ShellQuoteRedacted(args []string) string {
	redactNext := map[string]bool{"-password": true}
	return shellQuote(args, redactNext)
}

func shellQuote(args []string, redactNext map[string]bool) string {
	parts := make([]string, len(args))
	redact := false
	for i, a := range args {
		if redact {
			a = "***"
			redact = false
		}
		if redactNext != nil && redactNext[a] {
			redact = true
		}
		if runtime.GOOS == "windows" {
			parts[i] = quotePowerShell(a)
		} else {
			parts[i] = quotePOSIX(a)
		}
	}
	return strings.Join(parts, " ")
}

func quotePOSIX(a string) string {
	if a == "" {
		return "''"
	}
	if strings.IndexFunc(a, func(r rune) bool {
		return r == ' ' || r == '\t' || r == '\n' || r == '\'' || r == '"' || r == '$' || r == '\\' || r == ';' || r == '&' || r == '|' || r == '<' || r == '>' || r == '(' || r == ')'
	}) == -1 {
		return a
	}
	return "'" + strings.ReplaceAll(a, "'", "'\\''") + "'"
}

func quotePowerShell(a string) string {
	if a == "" {
		return "''"
	}
	if strings.IndexFunc(a, func(r rune) bool {
		return r == ' ' || r == '\t' || r == '\n' || r == '\'' || r == '"' || r == '$' || r == '`' || r == ';' || r == '&' || r == '|' || r == '<' || r == '>' || r == '(' || r == ')'
	}) == -1 {
		return a
	}
	return "'" + strings.ReplaceAll(a, "'", "''") + "'"
}

func isExecutablePath(path string) bool {
	st, err := os.Stat(path)
	if err != nil || st.IsDir() {
		return false
	}
	if runtime.GOOS == "windows" {
		return true
	}
	return st.Mode()&0o111 != 0
}

func formatAutoFirmaError(err error, res Result) error {
	stdout := strings.TrimSpace(res.Stdout)
	stderr := strings.TrimSpace(res.Stderr)
	cmd := ShellQuoteRedacted(append([]string{res.Command}, res.Args...))
	var parts []string
	parts = append(parts, fmt.Sprintf("AutoFirma falló: %v", err))
	if stderr != "" {
		parts = append(parts, "stderr: "+stderr)
	}
	if stdout != "" {
		parts = append(parts, "stdout: "+stdout)
	}
	if stderr == "" && stdout == "" {
		parts = append(parts, "sin salida por stdout/stderr")
	}
	parts = append(parts, "comando: "+cmd)
	parts = append(parts, "pistas: usa --doctor; en Windows comprueba que AutoFirma esté en PATH o usa --autofirma; en Linux prueba --probe-stores y --list-aliases --store mozilla")
	return errors.New(strings.Join(parts, "; "))
}

func normalizeConfigValue(s string, preserveSpaces bool) string {
	s = strings.ReplaceAll(s, "\r\n", " ")
	s = strings.ReplaceAll(s, "\n", " ")
	s = strings.ReplaceAll(s, "\r", " ")
	if !preserveSpaces {
		s = strings.Join(strings.Fields(s), "_")
	} else {
		s = strings.Join(strings.Fields(s), " ")
	}
	return escapePropertyValue(s)
}

func fmtFloat(v float64) string {
	n := int(math.Round(v))
	if n == 0 {
		return "0"
	}
	return fmt.Sprintf("%d", n)
}

func escapePropertyValue(s string) string {
	s = strings.ReplaceAll(s, "=", "\\=")
	return s
}
