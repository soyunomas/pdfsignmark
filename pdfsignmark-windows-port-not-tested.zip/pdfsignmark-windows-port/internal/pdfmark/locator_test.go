package pdfmark

import "testing"

func TestFindMarkerSingleWord(t *testing.T) {
	words := []Word{{PageNumber: 1, PageWidth: 612, PageHeight: 792, Text: "[FIRMA]", Box: Box{XMin: 10, YMin: 20, XMax: 50, YMax: 40}}}
	matches := FindMarker(words, "[FIRMA]", false)
	if len(matches) != 1 {
		t.Fatalf("matches = %d, want 1", len(matches))
	}
}

func TestFindMarkerMultiWordIgnoresSpaces(t *testing.T) {
	words := []Word{
		{PageNumber: 1, PageWidth: 612, PageHeight: 792, Text: "Firmado", Box: Box{XMin: 10, YMin: 20, XMax: 50, YMax: 40}},
		{PageNumber: 1, PageWidth: 612, PageHeight: 792, Text: "por", Box: Box{XMin: 55, YMin: 20, XMax: 70, YMax: 40}},
		{PageNumber: 1, PageWidth: 612, PageHeight: 792, Text: "solicitante:", Box: Box{XMin: 75, YMin: 20, XMax: 140, YMax: 40}},
	}
	matches := FindMarker(words, "Firmado por solicitante", false)
	if len(matches) != 1 {
		t.Fatalf("matches = %d, want 1", len(matches))
	}
}

func TestCaseInsensitive(t *testing.T) {
	words := []Word{{PageNumber: 1, PageWidth: 612, PageHeight: 792, Text: "firmado", Box: Box{XMin: 10, YMin: 20, XMax: 50, YMax: 40}}}
	matches := FindMarker(words, "FIRMADO", true)
	if len(matches) != 1 {
		t.Fatalf("matches = %d, want 1", len(matches))
	}
}

func TestRectForMatchCenter(t *testing.T) {
	m := Match{PageNumber: 1, PageWidth: 612, PageHeight: 792, BoxTopLeft: Box{XMin: 100, YMin: 200, XMax: 140, YMax: 220}}
	r := RectForMatch(m, 220, 80, 0, 0, 5, AnchorCenter)
	if r.Page != 1 || r.LLX <= 0 || r.LLY <= 0 || r.URX-r.LLX != 220 || r.URY-r.LLY != 80 {
		t.Fatalf("unexpected rect: %+v", r)
	}
}

func TestParseAnchor(t *testing.T) {
	for _, s := range []string{"center", "lower-left", "top_left"} {
		if _, err := ParseAnchor(s); err != nil {
			t.Fatalf("ParseAnchor(%q): %v", s, err)
		}
	}
	if _, err := ParseAnchor("bad"); err == nil {
		t.Fatal("ParseAnchor(bad) returned nil error")
	}
}
