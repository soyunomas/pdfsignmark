Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Set-Location (Join-Path $PSScriptRoot "..")

New-Item -ItemType Directory -Force -Path "bin" | Out-Null
go build -buildvcs=false -trimpath -ldflags="-s -w" -o "bin\pdfsignmark.exe" ".\cmd\pdfsignmark"

Write-Host "`n== Diagnostico =="
try {
  .\bin\pdfsignmark.exe --doctor
} catch {
  Write-Host "El diagnostico puede fallar si faltan Poppler, Ghostscript o AutoFirma. Usa rutas explicitas con --pdftotext, --gs y --autofirma."
}

Write-Host "`n== Marcadores detectados =="
.\bin\pdfsignmark.exe --list-markers .\examples\marker-test.pdf

Write-Host "`n== Dry run =="
.\bin\pdfsignmark.exe --dry-run --v .\examples\marker-test.pdf
