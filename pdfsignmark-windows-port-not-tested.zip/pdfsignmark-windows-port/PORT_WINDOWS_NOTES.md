# Port Windows - notas de entrega

Implementado:

- Build Windows `bin/pdfsignmark.exe`.
- Target `make build-windows` y `make dist-windows`.
- Detección de AutoFirma en Windows (`AutoFirmaCommandLine.exe`, `AutoFirma.exe`, PATH y rutas típicas bajo Program Files / LocalAppData).
- Detección de Ghostscript en Windows (`gswin64c.exe`, `gswin32c.exe`, `gswin64.exe`, `gswin32.exe`, PATH y rutas típicas bajo Program Files/gs/gs*/bin).
- Detección de Poppler `pdftotext.exe` en Windows (`PATH` y rutas típicas de Poppler).
- Nuevo `--doctor` para diagnóstico de dependencias.
- `--probe-stores` con lista por sistema operativo.
- README actualizado con instrucciones Windows.
- Script `examples/run.ps1`.
- CI para `ubuntu-latest` y `windows-latest`.

Validado en el entorno de generación:

- `gofmt -w ./cmd ./internal`
- `go test ./...`
- `GOOS=windows GOARCH=amd64 go build ... -o bin/pdfsignmark.exe`
- `pdfsignmark --list-markers examples/marker-test.pdf`
- `pdfsignmark --dry-run --v examples/marker-test.pdf`

No validado aquí:

- Firma real con AutoFirma, porque AutoFirma no está instalado en el contenedor de generación.
- Certificados reales de Windows. Debe probarse con `--doctor`, `--probe-stores` y una firma real en una máquina Windows con AutoFirma instalado.
