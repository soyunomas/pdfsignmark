# pdfsignmark

CLI en Go para firmar muchos PDFs de golpe con AutoFirma, colocando una firma PAdES visible a partir de una referencia textual dentro de cada documento.

Por defecto busca el texto `[FIRMA]`, pero puedes usar cualquier palabra o frase con `--marker`, colocar el cajetín encima, debajo o centrado respecto a esa referencia, y decidir si el texto usado como referencia se oculta visualmente o se conserva.

`pdfsignmark` no implementa criptografía, no accede a claves privadas y no sustituye a AutoFirma. La firma real la hace AutoFirma. Esta herramienta localiza el marcador, calcula la posición de la firma visible, limpia el marcador si procede y llama a AutoFirma con los parámetros adecuados.

## Novedades de este port Windows

- Compilación `pdfsignmark.exe` con `make build-windows` o `go build`.
- Detección de AutoFirma en `PATH` y rutas típicas de Windows.
- Detección de Ghostscript como `gswin64c.exe`, `gswin32c.exe`, `gswin64.exe` o `gswin32.exe`.
- Detección de Poppler `pdftotext.exe` en `PATH` y rutas típicas.
- Nuevo comando `--doctor` para diagnosticar dependencias.
- Nuevo script `examples/run.ps1`.
- CI preparada para Linux y Windows.

## Cómo funciona

1. Extrae coordenadas de texto del PDF con `pdftotext -bbox`.
2. Localiza el marcador elegido, por defecto `[FIRMA]`.
3. Calcula el rectángulo de la firma visible usando `--anchor`, `--offset-x`, `--offset-y`, `--width` y `--height`.
4. Opcionalmente oculta visualmente el texto localizado con Ghostscript.
5. Invoca AutoFirma para generar la firma PAdES.

## Dependencias

Necesitas:

- Go 1.22 o superior para compilar.
- AutoFirma instalado.
- Poppler, concretamente `pdftotext` / `pdftotext.exe`.
- Ghostscript solo si quieres ocultar visualmente el marcador. Si usas `--keep-marker`, Ghostscript no se ejecuta.

## Windows

Compilar:

```powershell
go build -buildvcs=false -trimpath -ldflags="-s -w" -o bin\pdfsignmark.exe .\cmd\pdfsignmark
```

Diagnosticar dependencias:

```powershell
.\bin\pdfsignmark.exe --doctor
```

Si no están en el `PATH`, usa rutas explícitas:

```powershell
.\bin\pdfsignmark.exe `
  --pdftotext "C:\tools\poppler\Library\bin\pdftotext.exe" `
  --gs "C:\Program Files\gs\gs10.xx.x\bin\gswin64c.exe" `
  --autofirma "C:\Program Files\AutoFirma\AutoFirmaCommandLine.exe" `
  --dry-run --v .\documento.pdf
```

Ver marcadores:

```powershell
.\bin\pdfsignmark.exe --list-markers .\documento.pdf
```

Firmar conservando el marcador, útil para probar sin Ghostscript:

```powershell
.\bin\pdfsignmark.exe --keep-marker --overwrite --v .\documento.pdf
```

Firmar ocultando el marcador:

```powershell
.\bin\pdfsignmark.exe --overwrite --v .\documento.pdf
```

Probar almacenes de certificados:

```powershell
.\bin\pdfsignmark.exe --probe-stores
.\bin\pdfsignmark.exe --list-aliases --store auto
```

En Windows no se fuerza `--store mozilla` por defecto. Si no indicas `--store`, se deja que AutoFirma decida su almacén por defecto.

## Linux / Debian / Ubuntu

```bash
sudo apt update
sudo apt install -y poppler-utils ghostscript
make clean
make build
```

El binario queda en:

```bash
./bin/pdfsignmark
```

Crear paquete Debian local:

```bash
make deb
```

## Uso básico

```bash
./bin/pdfsignmark --list-markers documento.pdf
./bin/pdfsignmark --dry-run --v documento.pdf
./bin/pdfsignmark --overwrite --v documento.pdf
```

Firmar todos los PDF de una carpeta:

```bash
./bin/pdfsignmark --overwrite --v ./*.pdf
```

Usar otro texto como referencia:

```bash
./bin/pdfsignmark --marker 'Firmado por solicitante' --list-markers documento.pdf
```

La búsqueda ignora espacios internos introducidos por `pdftotext` y tolera puntuación pegada al final. Para búsqueda sin distinguir mayúsculas/minúsculas:

```bash
./bin/pdfsignmark --marker 'firmado por solicitante' --case-insensitive --list-markers documento.pdf
```

## Colocar la firma

El cajetín visible mide por defecto `220 x 80` puntos PDF. Puedes cambiarlo con:

```bash
./bin/pdfsignmark --width 220 --height 80 --overwrite --v documento.pdf
```

Anclajes:

- `--anchor center`: centra la firma sobre el marcador.
- `--anchor lower-left`: coloca la esquina inferior izquierda de la firma en la esquina inferior izquierda del marcador.
- `--anchor top-left`: coloca la esquina superior izquierda de la firma en la esquina superior izquierda del marcador.

Offsets:

```bash
./bin/pdfsignmark --offset-x 10 --offset-y 8 --overwrite --v documento.pdf
```

Si hay varios marcadores:

```bash
./bin/pdfsignmark --marker-index -1 --overwrite --v documento.pdf
./bin/pdfsignmark --marker-index 2 --overwrite --v documento.pdf
```

## Ocultar o conservar la referencia

Por defecto, `pdfsignmark` pinta un rectángulo blanco sobre el marcador antes de firmar. Es una ocultación visual, no semántica. Si el fondo no es blanco, usa `--keep-marker` o ajusta la plantilla.

```bash
./bin/pdfsignmark --keep-marker --overwrite --v documento.pdf
./bin/pdfsignmark --clean-padding 4 --overwrite --v documento.pdf
```

## Certificados

Opciones útiles:

```bash
./bin/pdfsignmark --probe-stores
./bin/pdfsignmark --list-aliases --store auto
./bin/pdfsignmark --alias 'ALIAS_ELEGIDO' --no-certgui --overwrite --v documento.pdf
./bin/pdfsignmark --store 'pkcs12:/ruta/certificado.p12' --password 'CONTRASEÑA' --overwrite --v documento.pdf
```

En Linux, si no indicas `--store`, `--alias`, `--filter` ni `--password`, se mantiene el comportamiento anterior: `--store mozilla` con selector gráfico. En Windows no se fuerza ese almacén.

## Diagnóstico

```bash
./bin/pdfsignmark --doctor
./bin/pdfsignmark --dry-run --v documento.pdf
```

`--doctor` comprueba la detección básica de `pdftotext`, Ghostscript y AutoFirma. Si usas `--keep-marker`, omite Ghostscript.

## Firma sin cajetín visible

```bash
./bin/pdfsignmark --visible-mode none --overwrite --v documento.pdf
```

## Texto personalizado dentro del cajetín

```bash
./bin/pdfsignmark --text 'Firmado_por_$$SUBJECTCN$$' --overwrite --v documento.pdf
```

Si al usar `--text` deja de verse la firma, quítalo y deja que AutoFirma use su texto por defecto.

## Limitaciones

- El marcador debe existir como texto real del PDF; si el PDF es una imagen escaneada, `pdftotext` no lo encontrará.
- La limpieza del marcador es visual, no elimina el texto interno del PDF.
- No edites el PDF después de firmarlo; cualquier modificación posterior puede invalidar la firma.
- `--strict-visible` es heurístico y no sustituye a una validación criptográfica.
